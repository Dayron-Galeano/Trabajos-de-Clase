package ejemplo_relaciones_composicion;

public class ContenedorTriangulos {
    public Triangulo[] contenedor;
    public int indice;
    
    public ContenedorTriangulos(){
        this.contenedor = new Triangulo[3];
        this.indice = 0;
    }
    
    public void agregarTriangulo(Triangulo triangulo){
        this.contenedor[this.indice] = triangulo;
        this.indice++;
    }
}
