package ejemplo_relaciones_composicion;

public class Triangulo {
    private double base;
    private double altura;
    private Punto punto;
    
    public double getBase(){
        return this.base;
    }
    
    public double getAltura(){
        return this.altura;
    }
    
    public Triangulo(double base, double altura, Punto punto){
        this.base = base;
        this.altura = altura;
        this.punto = punto;
    }
    
    public Triangulo(double base, double altura, double xi, double yi){
        this.base = base;
        this.altura = altura;
        this.punto = new Punto(xi, yi);
    }
    
    public double area(){
        return (this.base * this.altura)/2;
    }
    
    private double hipotenusa(){
        return (Math.sqrt(((Math.pow(this.base, 2)) + (Math.pow(this.altura, 2)))));
    }
    
    public double perimetro(){
        return (this.base + this.altura + this.hipotenusa());
    }
    
    public void info(){
        System.out.println("Altura: " + this.altura);
        System.out.println("Base: " + this.base);
        System.out.println("Hipotenusa: " + this.hipotenusa());
        System.out.println("Perimetro: " + this.perimetro());
        System.out.println("Area: " + this.area());
    }
    
}
