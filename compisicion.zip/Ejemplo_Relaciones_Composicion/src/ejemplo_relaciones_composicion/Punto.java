package ejemplo_relaciones_composicion;

public class Punto {
    private double xi;
    private double yi;
    
    public double getXi(){
        return this.xi;
    }
    
    public double getYi(){
        return this.yi;
    }
    
    public Punto(double xi, double yi){
        this.xi = xi;
        this.yi = yi;
    }
}
