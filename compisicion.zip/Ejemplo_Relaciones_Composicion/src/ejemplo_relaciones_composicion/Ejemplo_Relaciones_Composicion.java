package ejemplo_relaciones_composicion;

public class Ejemplo_Relaciones_Composicion {

    public static void main(String[] args) {
        Punto punto1 = new Punto(2, 2);
        //System.out.println("Punto1 (xi, yi): " + punto1.getXi() + "," + punto1.getYi());
        Triangulo triangulo1 = new Triangulo(3, 2, punto1);
        //System.out.println("Base: " + triangulo1.getBase());
        //System.out.println("Altura: " + triangulo1.getAltura());
        Triangulo triangulo2 = new Triangulo(5, 4, punto1);
        //System.out.println("Base: " + triangulo2.getBase());
        //System.out.println("Altura: " + triangulo2.getAltura());
        //System.out.println("Area: " + triangulo2.area());
        //System.out.println("Perimetro: " + triangulo2.perimetro());
        Triangulo triangulo3 = new Triangulo(3, 2, 7, 4);
        //triangulo3.hipotenusa();
        /*System.out.println("Area: " + triangulo3.area());
        System.out.println("Perimetro: " + triangulo3.perimetro());*/
        //triangulo3.info();
        ContenedorTriangulos contenedorT = new ContenedorTriangulos();
        contenedorT.agregarTriangulo(triangulo1);
        contenedorT.agregarTriangulo(triangulo2);
        contenedorT.agregarTriangulo(triangulo3);
    }    
}
