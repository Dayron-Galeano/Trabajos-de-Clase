package venta;
import java.util.Scanner;
public class Venta {
    public static Scanner entrada;
    public static void main(String[] args) {
        entrada = new Scanner (System.in);
        String respuesta = "";
        int cantidadProducto = 0;
        double valorProducto = 0;
        String nombreProducto = "";
        double sumaProductos = 0;
        double sumaProductosDescuento = 0;
        while(!respuesta.equals("fin")){
            System.out.println("Ingrese el nombre del producto: ");
            nombreProducto = entrada.next();
            System.out.println("Ingrese el valor unitario: ");
            valorProducto = entrada.nextDouble();
            System.out.println("Ingrese la cantidad del producto: ");
            cantidadProducto = entrada.nextInt();
            sumaProductos = sumaProductos + valorPorProducto(valorProducto, cantidadProducto);
            System.out.println("SI NO DESEA CONTINUAR DIGITE 'fin': ");
            respuesta = entrada.next();
            respuesta = respuesta.toLowerCase();
        }
        System.out.println("El valor antes del descuento fue de $COP: " + sumaProductos);
        System.out.println("El descuento fue de $COP: " + valorDescuento(sumaProductos));
        sumaProductosDescuento = valorDescuento(sumaProductos);
        System.out.println("El valor después de descuento es de $COP: " + valorPagar(sumaProductos, sumaProductosDescuento));
        //System.out.println("El valor después del descuento fue de $COP: " + (sumaProductos - valorDescuento(sumaProductos)) );
        
    }
    public static double valorPorProducto(double valorProducto, int cantidadProducto){
    return(valorProducto*cantidadProducto);
    }
    public static double valorDescuento(double sumaProductos){
    return (sumaProductos * (0.12));
    }
    public static double valorPagar(double sumaProductos, double valorDescuento){
    return sumaProductos - valorDescuento;
    }
}
 
