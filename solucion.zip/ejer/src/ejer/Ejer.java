package ejer;
import java.util.Random;
public class Ejer {

    public static void main(String[] args) {
        int[] miVector = new int[50];
        double suma = 0;
        Random aleatorio = new Random ();
        for(int i = 0;  i < 50; i ++){
            miVector[i] = aleatorio.nextInt(20);
            System.out.println(miVector[i]);
        }
        int pivoteMenor = miVector[0];
        int pivoteMayor = miVector[0];
        for(int i = 0;  i < 50; i ++){
            if (miVector[i] < pivoteMenor){
                pivoteMenor = miVector[i];
            }
            if (miVector[i] > pivoteMayor)
                pivoteMayor = miVector[i];
            suma = suma + miVector[i];
        }
    
        
    double promedio = suma/10;
    System.out.println("La sumatoria es: " + suma);
    System.out.println("El número mayor es: " + pivoteMayor);
    System.out.println("El número menor es: " + pivoteMenor);
    System.out.println("El promedio es: " + promedio);
    System.out.println("El número de pares es: " + pares(miVector));
    System.out.println("El número de impares es: " + impares(miVector));
    }
    public static int pares(int[] n){
    int numerosPares = 0;
    for (int k = 0; k < 50; k++){
        if (n[k] % 2 == 0){
            numerosPares = numerosPares + 1;
         }
    }
    return numerosPares;
    }
    
    public static int impares(int[] n){
    int numerosImpares = 0;
    for (int k = 0; k < 50; k++){
        if (n[k] % 2 != 0){
            numerosImpares = numerosImpares + 1;
         }
    }
    return numerosImpares;
    }
}

