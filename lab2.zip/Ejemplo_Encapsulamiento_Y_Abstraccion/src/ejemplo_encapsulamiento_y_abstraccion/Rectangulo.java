package ejemplo_encapsulamiento_y_abstraccion;

public class Rectangulo {
    private double ancho;
    private double alto;
    
    public double getAncho(){
        return this.ancho;
    }
    
    public double getAlto(){
        return this.alto;
    }
    
    public void setAncho(double ancho){
        this.ancho = ancho;
    }
    
    public void setAlto(double alto){
        this.alto = alto;
    }
    
    public Rectangulo(double ancho, double alto){
        this.ancho = ancho;
        this.alto = alto;
    }
    
    public double area(){
        return (this.ancho * this.alto);
    }
    
    public double perimetro(){
        return (this.ancho + this.ancho + this.alto + this.alto);
    }
    
    public void info(){
        System.out.println("Ancho: " + this.ancho);
        System.out.println("Alto: " + this.alto);
        System.out.println("Area: " + this.area());
        System.out.println("Perimetro: " + this.perimetro());
    }
    
}
