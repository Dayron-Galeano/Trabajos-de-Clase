package ejemplo_encapsulamiento_y_abstraccion;

public class Circulo {
    public double radio;
    
    public Circulo(double radio){
        this.radio = radio;
    }
    
    public double area(){
        return (3.1416*this.radio*this.radio);
    }
    
    public double perimetro(){
        return (2*3.1416*this.radio);
    }
    
    public void info(){
        System.out.println("Radio: " + this.radio);
        System.out.println("Area del circulo: " + this.area());
        System.out.println("Perimetro del circulo: " + this.perimetro());
    }
    
}
