package ejemplo_encapsulamiento_y_abstraccion;

public class Cuadrado {
    public double lado;
    
    public Cuadrado(double lado){
        this.lado = lado;
    }
    
    public double area(){
        return (this.lado * this.lado);
    }
    
    public double perimetro(){
        return (this.lado + this.lado + this.lado + this.lado);
    }
    
    public void info(){
        System.out.println("Lado del Cuadrado: " + this.lado);
        System.out.println("Area del Cuadrado: " + this.area());
        System.out.println("Perimetro del Cuadrado: " + this.perimetro());
    }
    
}
