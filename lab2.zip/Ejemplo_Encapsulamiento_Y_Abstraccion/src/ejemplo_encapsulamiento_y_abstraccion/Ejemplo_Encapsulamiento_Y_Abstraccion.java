package ejemplo_encapsulamiento_y_abstraccion;

public class Ejemplo_Encapsulamiento_Y_Abstraccion {

    public static void main(String[] args) {
        //Circulo circulo1 = new Circulo(20.5);
        //circulo1.info();
        //System.out.println(circulo1.radio);
        //System.out.println("Area del circulo 1: " + circulo1.area());
        //System.out.println("Perimetro del circulo 1: " + circulo1.perimetro());
        //Circulo circulo2 = new Circulo(18.3);
        //circulo2.info();
        
        //Rectangulo rectangulo1 = new Rectangulo(10, 12.2);
        //rectangulo1.info();
        /*System.out.println("Area del rectangulo 1: " + rectangulo1.area());
        System.out.println("Perimetro del rectangulo 1: " + rectangulo1.perimetro());*/
        //Rectangulo rectangulo2 = new Rectangulo(15, 20);
        //rectangulo2.info();
        /*System.out.println("Area del rectangulo 2: " + rectangulo2.area());
        System.out.println("Perimetro del rectangulo 2: " + rectangulo2.perimetro());*/
        
        //Cuadrado cuadrado1 = new Cuadrado(15.2);
        //cuadrado1.info();
        /*System.out.println("Lado del Cuadrado: " + cuadrado1.lado);
        System.out.println("Area del Cuadrado: " + cuadrado1.area());
        System.out.println("Perimetro del Cuadrado: " + cuadrado1.perimetro());*/
        //Cuadrado cuadrado2 = new Cuadrado(2);
        //cuadrado2.info();
        Rectangulo r1 = new Rectangulo(3, 2);
        r1.setAncho(4); // r1.ancho = 4;X
        r1.setAlto(3); //r1.alto = 3;
        System.out.println("Ancho rectangulo 1: " + r1.getAncho());
        System.out.println("Alto rectangulo 1: " + r1.getAlto());
    }    
}
