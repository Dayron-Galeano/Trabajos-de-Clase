package demo_universidad;

public class Estudiante {
    private String nombre;
    private int nivel;
    private Direccion direccion;
    
    public Estudiante(String nombre, int nivel){
        this.nombre = nombre;
        this.nivel = nivel;
        this.direccion = new Direccion("","","","","");
    }
    public Estudiante(String n, int nivel, Direccion dir){
        this.nombre = n;
        this.nivel = nivel;
        this.direccion = dir;
    }
    
    public void imprimir(){
        System.out.println("Nombre: " + this.nombre +
                " Nivel: " + this.nivel +
                " Dirección: " + this.direccion.getTexto() + "," +
                this.direccion.getBarrio() + "," +
                this.direccion.getCiudad() + "," +
                this.direccion.getDepartamento() + "," +
                this.direccion.getPais());
    }
}
