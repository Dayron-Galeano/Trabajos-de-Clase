package demo_universidad;

public class Direccion {
    private String texto;
    private String barrio;
    private String ciudad;
    private String departamento;
    private String pais;
    
    public void setTexto(String texto){
     this.texto = texto;
    }
    
    public void setBarrio(String barrio){
     this.barrio = barrio;
    }
    
    public void setCiudad(String ciudad){
     this.ciudad = ciudad;
    }
    
    public void setDepartamento(String departamento){
     this.departamento = departamento;
    }
    
    public void setPais(String pais){
     this.pais = pais;
    }
    
    public String getTexto(){
        return this.texto;
    }
    
    public String getBarrio(){
        return this.barrio;
    }
    
    public String getCiudad(){
        return this.ciudad;
    }
    
    public String getDepartamento(){
        return this.departamento;
    }
    
    public String getPais(){
        return this.pais;
    }

    public Direccion(String texto, String barrio, String ciudad, String departamento, String pais){
        this.texto = texto;
        this.barrio = barrio;
        this.ciudad = ciudad;
        this.departamento = departamento;
        this.pais = pais;
    } 
}


