package demo_universidad;

public class Demo_Universidad {

    public static void main(String[] args) {
        Direccion direccion1 = new Direccion("Cra 27 9", "Ciudad Universitaria", "Bucaramanga", "Santander", "Colombia");
        Direccion direccion2 = new Direccion("Cra 15 105", "Provenza", "Bucaramanga", "Santander", "Colombia");
        System.out.println(direccion1.getTexto());
        direccion1.setTexto("Cr 7 35");
        System.out.println(direccion1.getTexto());
        Estudiante estudiante1 = new Estudiante("Pepito", 2);
        Estudiante estudiante2 = new Estudiante("Funalito", 5, direccion1);
        estudiante2.imprimir();
    }
    
}
