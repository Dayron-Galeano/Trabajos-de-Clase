package ejemploderelacióndedependencia;

public class EjemploDeRelaciónDeDependencia {

    public static void main(String[] args) {
        NumerosPrimos numeros_primos = new NumerosPrimos(25);
        numeros_primos.generarNumeros();
        System.out.println("Cantidad de números primos: " + numeros_primos.contarNumeros());
        numeros_primos.info();
    }
    
}
