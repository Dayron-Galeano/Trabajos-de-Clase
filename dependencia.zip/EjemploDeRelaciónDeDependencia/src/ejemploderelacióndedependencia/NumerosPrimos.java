package ejemploderelacióndedependencia;
import java.util.Random;
public class NumerosPrimos {
    private int[] nums;
    
    public NumerosPrimos(int tamaño){
        this.nums = new int[tamaño];
    }
    
    public void generarNumeros(){
        Random random = new Random();
        for(int i = 0; i < this.nums.length; i++){
            this.nums[i] = random.nextInt(100);
        }    
    }
    
    public int contarNumeros(){
        int primos = 0;
        for(int i = 0; i < this.nums.length; i++){
            if (this.esPrimo(this.nums[i])){
                primos++;
            }
        }
        return primos;
    }
    
    private boolean esPrimo(int numero){
        int contador = 0;
        for(int i = 1; i <= numero; i++){
            if((numero % i) == 0){
            contador++;
            }
        }
        if (contador == 2){
        return true;
        } 
        else{
        return false;
        }
    }
    
    public void info(){
        for(int i = 0; i < this.nums.length; i++){
            System.out.println(this.nums[i]);
        }
    }
}
