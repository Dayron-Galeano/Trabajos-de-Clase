package exercise;
import java.util.Scanner;
public class Exercise {
    public static Scanner entrada = new Scanner (System.in);
    public static void main(String[] args) {
    System.out.println("Digite la figura geometrica ('cir', 'rec' o 'cua')");
    String figura = entrada.nextLine();
    double radio, lado, base, altura;
    double perimetro, area;
    perimetro = 0;
    area = 0;
    switch(figura.toLowerCase()){
        case "cir":
            System.out.println("Digite el radio del circulo");
            radio = entrada.nextDouble();
            perimetro = cal_perimetro_cir(radio);
            area = cal_area_cir(radio);
            System.out.println("El area es: " + area + " y el perimetro es: "+ perimetro);
            break;
            
        case "rec":
            System.out.println("Digite la longitud de la base del rectangulo");
            base = entrada.nextDouble();
            System.out.println("Digite la longitud de la altura del rectangulo");
            altura = entrada.nextDouble();
            perimetro = recper(base,altura);
            area = recare(base,altura);
            System.out.println("El area es: " + area + " y el perimetro es: "+ perimetro);
            break;
        case "cua":
            System.out.println("Digite la longitud del lado del cuadrado");
            lado = entrada.nextDouble();
            perimetro = cuaper(lado);
            area = cuare(lado);
            System.out.println("El area es: " + area + " y el perimetro es: "+ perimetro);
            break;
    }
    
    }
    public static double cal_perimetro_cir(double radio){
    double perimetro = 2 * radio * Math.PI;
    return perimetro;
    }
    public static double cal_area_cir(double radio){
    double area = radio * radio * Math.PI;
    return area;
    }
    public static double recper(double base, double altura){
    double perimetro = 2 * base + 2 * altura ;
    return perimetro;
    }
    public static double recare(double base, double altura){
    double area = base * altura;
    return area;
    }
    public static double cuare(double lado){
    double area = lado * lado;
    return area;
    }
    public static double cuaper(double lado){
    double per = lado * 4;
    return per;
    }
}
